#!/usr/bin/env python
from ..Aplicativo import teach

