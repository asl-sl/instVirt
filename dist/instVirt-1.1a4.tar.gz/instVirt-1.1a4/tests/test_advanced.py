#!/usr/bin/env python

from .context import Aplicativo
