**============
Instrutor virtual
============**
Aplicativo para auxílio 
*****************
em sala de aula.
Este se aplica ao curso de capacitação em ciência da computação.
**Academia do software livre**
Até o momento temos dez etapas para o curso, divididas em quatro disciplinas.



Autor(Leonardo de Araújo Lima).

(leonardo@asl-sl.com.br).
