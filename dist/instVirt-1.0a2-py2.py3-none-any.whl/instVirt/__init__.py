'''Este aplicativo constrói a interface para auxílio em sala de aula.
Desenvolvido dentro da filosofia de software livre.
Academia do softwre livre'''
__version__="1.0a2"
